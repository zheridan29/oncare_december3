.. _arima_examples:

ARIMA examples
--------------

Examples of how to use the :mod:`pmdarima.arima` module to fit timeseries
models.

.. raw:: html

   <br/>
